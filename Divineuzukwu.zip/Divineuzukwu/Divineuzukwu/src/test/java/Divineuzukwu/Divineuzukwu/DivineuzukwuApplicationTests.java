package Divineuzukwu.Divineuzukwu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DivineuzukwuApplicationTests {

	@Test
	void contextLoads() {
	}

}
