package Divineuzukwu.Divineuzukwu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DivineuzukwuApplication {

	public static void main(String[] args) {
		SpringApplication.run(DivineuzukwuApplication.class, args);
	}

}
